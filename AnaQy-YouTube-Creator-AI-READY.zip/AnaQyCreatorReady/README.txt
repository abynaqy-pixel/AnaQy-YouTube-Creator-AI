AnaQy YouTube Creator AI — Netlify-ready source project

IMPORTANT: Deploy this project through a Git repository connected to Netlify (GitHub), not Netlify Drop. Netlify Drop static upload does not run/build the bundled Functions reliably.

Files:
- index.html
- netlify.toml
- netlify/functions/generate.js

Deployment:
1. Upload these files/folders to a GitHub repository (repository root must contain index.html and netlify.toml; preserve netlify/functions/generate.js path).
2. In Netlify, Add new project/site > Import from Git > GitHub, authorize and select this repository.
3. Deploy settings: build command empty; publish directory '.' (netlify.toml also sets these); functions directory 'netlify/functions'.
4. Netlify project/site configuration > Environment variables: add GEMINI_API_KEY with your Gemini key value. Do not commit key to GitHub or put it in index.html.
5. Trigger deploy/redeploy after saving variable. Confirm deploy log shows the function 'generate' included.
6. Open deployed site and test.

If deploy errors occur, check the deploy log. Never share API key in screenshots/chats.
