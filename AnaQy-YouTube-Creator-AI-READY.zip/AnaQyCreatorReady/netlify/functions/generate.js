exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };
  const key = process.env.GEMINI_API_KEY;
  if (!key) return { statusCode: 500, body: JSON.stringify({ error: 'GEMINI_API_KEY belum diatur di Netlify.' }) };
  try {
    const { topic, type, duration, style, lang, extra } = JSON.parse(event.body || '{}');
    const prompt = `Bertindak sebagai YouTube content strategist, penulis skenario, dan prompt engineer. Buat paket konten lengkap berdasarkan data ini:\nTopik: ${topic}\nJenis: ${type}\nDurasi: ${duration}\nGenre: ${style}\nBahasa: ${lang}\nDetail: ${extra || '-'}\n\nSusun output dengan bagian: (1) 5 judul menarik, (2) hook 3 detik, (3) script/naskah sesuai durasi, (4) pembagian scene bernomor beserta durasi, dialog, dan arahan kamera, (5) prompt gambar tiap scene yang konsisten karakter dan berbahasa Indonesia, (6) prompt video tiap scene dengan gerakan kamera dan aksi, (7) prompt thumbnail tanpa tulisan kecuali diminta, (8) deskripsi YouTube, (9) hashtag, (10) kata kunci SEO. Berikan output rapi, praktis, siap disalin. Gunakan bahasa yang diminta.`;
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(key), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
    });
    const json = await response.json();
    if (!response.ok) return { statusCode: response.status, body: JSON.stringify({ error: json.error?.message || 'Gemini API error' }) };
    const text = json.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('\n') || 'Tidak ada hasil.';
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) };
  } catch (e) { return { statusCode: 500, body: JSON.stringify({ error: e.message || 'Terjadi kesalahan.' }) }; }
};
